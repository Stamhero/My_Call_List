package com.example.mycalllist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.os.Bundle;

import com.example.mycalllist.databinding.ActivityMainBinding;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    ContactDao contactDao;
    List<Contact> contacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        contacts = createNewContactsList();
        setUpDatabase();
        getAllUsers();
        setUpRecyclerView();
        //insertNewUser("tom","kabab","04698438");

    }

    public List createNewContactsList() {
      return List.of();
    }

    public void setUpDatabase() {
        MyDatabase database = Room.databaseBuilder(getApplicationContext(), MyDatabase.class, "my-database")
                .allowMainThreadQueries() // Only for testing purposes. Don't use this in production.
                .build();

        contactDao = database.userDao();
    }

    public void insertNewUser(String firstName, String lastName, String phone) {
        Contact newContact = new Contact(firstName, lastName,phone);
        contactDao.insert(newContact);
    }

    public void getAllUsers() {
        contacts = contactDao.getAllUsers();
    }

    // this code set the adapter of the recyclerView.
    public void setUpRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.RVCall_list);
        RV_contact_adapter adapter = new RV_contact_adapter(contacts);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void updateUser(Contact contact) {
        contactDao.delete(contact);
    }
}